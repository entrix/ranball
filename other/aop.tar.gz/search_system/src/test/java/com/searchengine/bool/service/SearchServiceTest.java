package com.searchengine.bool.service;

import com.searchengine.bool.domain.Document;
import com.searchengine.bool.domain.IToken;
import com.searchengine.bool.util.WordTokenizer;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: entrix
 * Date: 16.03.2012
 * Time: 23:13
 * To change this template use File | Settings | File Templates.
 */
public class SearchServiceTest {

//    @Before
//    public void setUp() {
//        searcher = new Searcher();
//    }

    @Test
    public void testFindDocument() {
        List<IToken<String>> tokens = tokens = (List<IToken<String>>)
                new WordTokenizer().getTokensFromDocument(new Document(
                        "first step in the agression intervention"
                ));
        List<Boolean> signs = new ArrayList<Boolean>(3);
        List<Long> answer   = new ArrayList<Long>();
        signs.add(true);
        signs.add(true);
        signs.add(true);

        answer = SearchService.findDocument(tokens, signs);
    }
}
