package com.searchengine.bool.domain;

import org.junit.Assert;
import org.junit.Test;

/**
 * Created with IntelliJ IDEA.
 * User: oracle
 * Date: 18.02.13
 * Time: 11:46
 * To change this template use File | Settings | File Templates.
 */
public class TermTest {

    @Test
    public void testSetters() {
        ITerm<String> term = new Term<String>("java");
        IToken<String> token = new Token<String>("java");

        term.addRelatedToken(token);

        Assert.assertEquals("Value must be the same", term.getValue(), "java");
        Assert.assertEquals("Value must be the same", term.getRelatedTokens().get(0),
                token);
        Assert.assertEquals("Value must be the same", term.getRelatedTokens().get(0).getValue(),
                "java");
    }
}
