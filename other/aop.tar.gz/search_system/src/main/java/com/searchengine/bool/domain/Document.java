package com.searchengine.bool.domain;

/**
 * Created by IntelliJ IDEA.
 * User: entrix
 * Date: 16.03.2012
 * Time: 23:13
 * To change this template use File | Settings | File Templates.
 */
public class Document implements IDocument {

    private static long maxId = -1;

    long docId = 0;

    String content = new String();

    public Document() {
        maxId++;
    }

    public Document(String content) {
        maxId++;
        this.docId = maxId;
        this.content = new String(content);
    }

    public Document(Document document) {
        maxId++;
        this.docId = maxId;
        this.content = new String(document.getContent());
    }

    @Override
    public String getContent() {
        return content;
    }

    @Override
    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public long getDocId() {
        return docId;
    }

    @Override
    public void setDocId(long docId) {
        this.docId = docId;
    }
}
