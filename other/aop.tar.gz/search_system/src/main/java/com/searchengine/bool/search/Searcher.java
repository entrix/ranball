package com.searchengine.bool.search;

import com.searchengine.bool.domain.ITerm;
import com.searchengine.bool.domain.SearchParameter;
import com.searchengine.bool.domain.Term;

import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: entrix
 * Date: 16.03.2012
 * Time: 23:13
 * To change this template use File | Settings | File Templates.
 */
public class Searcher implements ISearcher {

    private SystemState state;
    private List<List<Long>> postings;
    private List<Boolean>    signs;
    private List<ITerm>      terms;

    private static Comparator<Map.Entry<Term, Boolean>> comparator = new Comparator<Map.Entry<Term, Boolean>>() {
        @Override
        public int compare(Map.Entry<Term, Boolean> e1, Map.Entry<Term, Boolean> e2) {
            return e1.getKey().getValue().compareTo(e2.getKey().getValue());
        }
    };

    public Searcher() {
        this.state = new SystemState();
    }

    @Override
    public void prepareSearch(List<SearchParameter> searchParameters) {
        signs = new ArrayList<Boolean>(searchParameters.size());
        terms = new ArrayList<ITerm>(searchParameters.size());

        Map<Term, Boolean> params = new TreeMap<Term, Boolean>();

        for (SearchParameter parameter : searchParameters) {
            params.put((Term) parameter.getTerm(), parameter.getSign());
        }

        List<Map.Entry<Term, Boolean>> entryList =
                new ArrayList<Map.Entry<Term, Boolean>>(params.entrySet());
        Collections.sort(entryList, comparator);

        postings = state.getPostingsSortedByFrequencies(terms, signs);
    }

    /**
     * Engine kernel of the Boolean Search
     *
     * @param searchParameters - list of the search parameters
     * @return
     */
    @Override
    public List<Long> performSearch(List<SearchParameter> searchParameters) {

        List<List<Long>> postings =
                new ArrayList<List<Long>>(this.postings);

        // retrieve the first list from all postings
        List<Long> result  = postings.get(0);

        // search
        for (int i = 1; !postings.isEmpty() && !result.isEmpty(); ++i) {
            intersection(result, postings.get(i), signs.get(i));
            postings.remove(i);
        }

        return result;
    }

    private void intersection(List<Long> result, List<Long> next, boolean sign) {
        if (sign == true) {
            result.retainAll(next);
        }
        else {
            List<Long> current = new ArrayList<Long>(result);
            current.retainAll(next);
            result.removeAll(current);
        }
    }

    @Override
    public void addTerms(List<ITerm> terms, Long docId) {
        state.addTerms(terms, docId);
    }
}
