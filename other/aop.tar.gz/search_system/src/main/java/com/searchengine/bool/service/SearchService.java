package com.searchengine.bool.service;

import com.searchengine.bool.domain.*;
import com.searchengine.bool.search.ISearcher;
import com.searchengine.bool.search.Searcher;
import com.searchengine.bool.util.ITerminator;
import com.searchengine.bool.util.ITokenizer;
import com.searchengine.bool.util.WordTerminator;
import com.searchengine.bool.util.WordTokenizer;

import java.util.*;

/**
 * Service Layer for find satysfying
 * the search criteria
 *
 * Created by IntelliJ IDEA.
 * User: entrix
 * Date: 16.03.2012
 * Time: 23:13
 * To change this template use File | Settings | File Templates.
 */
public class SearchService {

    private static ISearcher   searcher;
    private static ITerminator terminator;
    private static ITokenizer  tokenizer;
    
    static {
        searcher   = new Searcher();
        terminator = new WordTerminator();
        tokenizer  = new WordTokenizer();
    }
    /**
     *
     *
     * @param tokens - vector of tokens
     * @param signs - vector of token signs
     * @return
     */
    public static List<Long> findDocument(List<IToken<String>> tokens, List<Boolean> signs) {
        List<Term<String>> terms = new ArrayList<Term<String>>();

        // get terms with respect to tokens
        for (IToken token : tokens) {
            terms.add((Term) terminator.getTermRelatedToToken(token));    
        }

        List<SearchParameter> searchParameters =
                new ArrayList<SearchParameter>(terms.size());
        Iterator it = signs.iterator();
        
        // construct the search parameters
        for (ITerm term : terms) {
            searchParameters.add(
                    new SearchParameter(term, (Boolean) it.next()));
        }

        return searcher.performSearch(searchParameters);
    }

    public static boolean addDocument(IDocument document) {
        List<ITerm> terms = new ArrayList<ITerm>();
        List<IToken> tokens = tokenizer.getTokensFromDocument(document);

        // get terms with respect to tokens
        for (IToken token : tokens) {
            terms.add(terminator.getTermRelatedToToken(token));
        }

        searcher.addTerms(terms, document.getDocId());
        return true;
    }

    public static boolean addDocuments(List<IDocument> document) {

        return true;
    }
}
