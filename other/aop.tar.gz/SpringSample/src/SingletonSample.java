import ru.mai.springsample.CustomerService;
import ru.mai.springsample.EmailService;

/**
 * Created by IntelliJ IDEA.
 * User: Eugene
 * Date: 13.11.2010
 * Time: 19:16:39
 * To change this template use File | Settings | File Templates.
 */
public class SingletonSample {

    public static class MockEmailService extends EmailService {

        public MockEmailService() {
        }

        @Override
        public void sendEmail() {
            System.out.println("Mock Email sent");
        }
    }


    public static void main(String[] args) {
//        DocumentBuilderFactory.newInstance();
//        System.setProperty("ru.mai.springsample.EmailService.class", MockEmailService.class.getName());
//        System.setProperty("javax.xml.parsers.DocumentBuilderFactory", "");
//        ServiceLocator.getInstance().setEmailService(new MockEmailService());


        CustomerService customerService = ServiceLocator.getInstance().getCustomerService();

//        customerService.setEmailService(new MockEmailService());
        customerService.notifyCustomer();
    }
}
