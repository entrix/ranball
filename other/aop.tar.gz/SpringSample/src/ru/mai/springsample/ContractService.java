package ru.mai.springsample;

/**
 * Created by IntelliJ IDEA.
 * User: Eugene
 * Date: 13.11.2010
 * Time: 20:24:57
 * To change this template use File | Settings | File Templates.
 */
public class ContractService {
    private EmailService emailService;

    public void setEmailService(EmailService emailService) {
        this.emailService = emailService;
        System.out.println(emailService);
    }
}
