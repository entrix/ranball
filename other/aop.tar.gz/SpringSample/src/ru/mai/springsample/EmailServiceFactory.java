package ru.mai.springsample;

import org.springframework.beans.factory.FactoryBean;

/**
 * Created by IntelliJ IDEA.
 * User: Eugene
 * Date: 13.11.2010
 * Time: 20:26:04
 * To change this template use File | Settings | File Templates.
 */
public class EmailServiceFactory implements FactoryBean {

    public Object getObject() throws Exception {
        System.out.println("Creating new EMailService");
        return new EmailService();
    }

    public Class<?> getObjectType() {
        return EmailService.class;
    }

    public boolean isSingleton() {
        return false;
    }
}
