package ru.mai.springsample;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

/**
 * Created by IntelliJ IDEA.
 * User: Eugene
 * Date: 13.11.2010
 * Time: 20:30:22
 * To change this template use File | Settings | File Templates.
 */
@Aspect
public class MailAspect {

    @Pointcut("execution(public * ru.mai.springsample.*.notify*(..))")
    public void methodsForNotifications() {}

    @Around("methodsForNotifications()")
    public void notify(ProceedingJoinPoint pjp) throws Throwable {
        pjp.proceed();
        System.out.println("Sending email from Aspect");
    }

}


