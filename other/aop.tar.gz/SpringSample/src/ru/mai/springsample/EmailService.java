package ru.mai.springsample;

import org.springframework.stereotype.Component;

/**
* Created by IntelliJ IDEA.
* User: Eugene
* Date: 13.11.2010
* Time: 19:35:02
* To change this template use File | Settings | File Templates.
*/
@Component
public class EmailService {
//
//    private static ru.mai.springsample.EmailService instance = new ru.mai.springsample.EmailService();
//
//    public static ru.mai.springsample.EmailService getInstance() {
//        String className = System.getProperty("ru.mai.springsample.EmailService.class");
//        if (className != null) {
//            try {
//                return (ru.mai.springsample.EmailService) Class.forName(className).newInstance();
//            } catch (Exception e) {
//                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
//            }
//        }
//        return instance;
//    }
   
    public void sendEmail() {
        System.out.println("Email sent");
    }

    public void setFrom(String s) {
        System.out.println("Sending emails from " + s);
    }
}
