package ru.mai.springsample;

import org.springframework.beans.factory.annotation.Autowire;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
* Created by IntelliJ IDEA.
* User: Eugene
* Date: 13.11.2010
* Time: 19:35:17
* To change this template use File | Settings | File Templates.
*/
@Transactional
@Component
@Configurable(autowire=Autowire.BY_NAME,dependencyCheck=true,preConstruction = true)
public class CustomerService {

    @Autowired
    private EmailService emailService;

    public void notifyCustomer() {
            System.out.println("Notifying customer...");
        emailService.sendEmail();            
    }

}
