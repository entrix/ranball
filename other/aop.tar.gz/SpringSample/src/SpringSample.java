import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import ru.mai.springsample.CustomerService;

/**
 * Created by IntelliJ IDEA.
 * User: Eugene
 * Date: 13.11.2010
 * Time: 20:02:12
 * To change this template use File | Settings | File Templates.
 */
public class SpringSample {

    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("context.xml");

        CustomerService customerService = context.getBean(CustomerService.class);
        customerService.notifyCustomer();
    }
}
