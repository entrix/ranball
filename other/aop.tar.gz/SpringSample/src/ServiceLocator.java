import ru.mai.springsample.CustomerService;
import ru.mai.springsample.EmailService;

/**
 * Created by IntelliJ IDEA.
 * User: Eugene
 * Date: 13.11.2010
 * Time: 19:32:48
 * To change this template use File | Settings | File Templates.
 */
public class ServiceLocator {
    private static ServiceLocator instance = new ServiceLocator();

    public static ServiceLocator getInstance() {
        return instance;
    }

    private CustomerService customerService = new CustomerService();
    private EmailService emailService = new EmailService();

    public ServiceLocator() {
//        customerService.setEmailService(emailService);
//        autowire(customerService);
    }

    public EmailService getEmailService() {
        return emailService;
    }

    public CustomerService getCustomerService() {
        return customerService;
    }

    public void setCustomerService(CustomerService customerService) {
        this.customerService = customerService;
    }

    public void setEmailService(EmailService emailService) {
        this.emailService = emailService;
    }
}
